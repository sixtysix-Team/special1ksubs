#!/bin/bash
#multitools
#special 1k subscribe
#aunthor : David Apriyanto (Blank)
#team : sixtysix-Team
#github : https://github.com/sixtysix-Team
#color
b='\033[34;1m'
g='\033[32;1m'
p='\033[35;1m'
c='\033[36;1m'
r='\033[31;1m'
w='\033[37;1m'
y='\033[33;1m'
main(){
		echo $r"	["$y"#"$r"]"$w" silahkan pilih option" $r"["$y"#"$r"]"
		echo""
		echo $r"["$y"1"$r"]"$w" domain target (URL)" $y"["$g"✓"$y"]" $g"connect"
		echo $r"["$y"2"$r"]"$w" source email" $y"	["$g"✓"$y"]" $g"connect"
		echo $r"["$y"3"$r"]"$w" email breached" $y"	["$g"✓"$y"]" $g"connect"
		echo $r"["$y"4"$r"]"$w" email informations" $y"	["$g"✓"$y"]" $g"connect"
		echo $r"["$y"99"$r"]"$w" exit" $y"		["$r"?"$y"]" $c"exit"
		echo""
		echo $r"["$y"#"$r"]"$w" masukkan pilihan №"$c
		read -p "input : " no
		if [ $no = "1" ]; then
			read -p "target : " target
			python infoga.py -d $target -v 3
		elif [ $no = "2" ]; then
			read -p "target : " target
			python infoga.py -s all $target
		elif [ $no = "3" ]; then
			read -p "target : " target
			python infoga.py -d $target -s all -b -v 1
		elif [ $no = "4" ]; then
			read -p "target : " target
			python infoga.py -i $target
		elif [ $no = "99" ]; then
			echo $r"["$y"#"$r"]" $w"terimakasih atas dukungan kalian semua"
			echo $r"["$y"#"$r"]" $w"tetap dukung chanell "$g"hack 606 "$w"supaya terus berkembang yaa"
			exit
		else
			echo $r"["$y"#"$r"]" $w"kesalahan parse.."
			exit
		fi
}
main